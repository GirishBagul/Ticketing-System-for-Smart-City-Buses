import 'package:flutter/widgets.dart';
import 'package:flutter_application_2/widgets/auth_screen.dart';
import 'package:flutter_application_2/widgets/home.dart';
import 'package:flutter_application_2/service/user.dart';
import 'package:provider/provider.dart';

class Wrapper extends StatelessWidget {
  const Wrapper({super.key});

  @override
  Widget build(BuildContext context) {
    final user = Provider.of<MyUser?>(context);

    if (user == null) {
      return const authenticate();
    } else {
      return const Home();
    }
  }
}
