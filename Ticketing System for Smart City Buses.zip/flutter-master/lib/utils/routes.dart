class MyRoutes {
  static String loginroute = "/login";
  static String forgotpassroute = "/forgotpass";
  static String homeroute = "/home";
  static String mydrawerroute = "/mydrawer";
  static String personalroute = "/personal";
  static String historyroute = "/history";
  static String signuproute = "/signup";
  static String busspassroute = "/buspass";
  static String tickitPage = "/tickitpage";
}
