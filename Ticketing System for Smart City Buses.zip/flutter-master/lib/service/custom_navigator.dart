import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter_application_2/service/auth.dart';
import 'package:flutter_application_2/widgets/buspass.dart';

final MyAuthService _auth = MyAuthService();

class CustomNavigator {
  final String uid = _auth.getCurrentUid();
  void navigateToBuspass(BuildContext context) {
    FirebaseFirestore.instance
        .collection('User')
        .doc(uid)
        .collection('ActivePass')
        .get()
        .then((QuerySnapshot snapshot) {
      if (snapshot.docs.isNotEmpty) {
        showDialog(
            context: context,
            builder: (ctx) {
              return AlertDialog(
                actions: [
                  TextButton(
                    onPressed: () {
                      Navigator.pop(context);
                    },
                    child: const Text('Okay'),
                  ),
                ],
                title: const Text("Can't buy a new pass right now."),
                content: const Text(
                    "You already have a pass. Check in the 'Active Pass' section."),
              );
            });
      } else {
        Navigator.of(context).push(
          MaterialPageRoute(
            builder: (ctx) => const BusPass(),
          ),
        );
      }
    });
  }
}
