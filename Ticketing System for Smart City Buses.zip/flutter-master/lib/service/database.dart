// ignore_for_file: avoid_print

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class DatabaseService {
  DatabaseService({required this.uid});

  String uid;
  String myDoceId = 'sam7770008123';

  Future<void> addPassHistory(String name, String phone, String duration,
      String purchasedDate, DateTime expDate) async {
    final CollectionReference historyCollection =
        FirebaseFirestore.instance.collection('User');
    try {
      await historyCollection.doc(uid).collection('PassHistory').add({
        'name': name,
        'phone': phone,
        'duration': duration,
        'purchased_date': purchasedDate,
        'Expiry_date': expDate,
      });
      print('Data added successfully.');
    } catch (e) {
      print('Error adding data: $e');
    }
  }

  Future<void> addActivePass(String name, String phone, String duration,
      String purchasedDate, DateTime expDate) async {
    final CollectionReference activePass =
        FirebaseFirestore.instance.collection('User');
    await activePass.doc(uid).collection('ActivePass').doc(myDoceId).set({
      'name': name,
      'phone': phone,
      'duration': duration,
      'purchased_date': purchasedDate,
      'Expiry_date': expDate,
    });
  }

  Future<void> addActivePassDelete() async {
    final CollectionReference activePassDelete =
        FirebaseFirestore.instance.collection('User');
    try {
      await activePassDelete
          .doc(uid)
          .collection('ActivePass')
          .doc(myDoceId)
          .delete();
      print("Active pass deleted successfully");
    } catch (e) {
      print(e);
    }
  }

  Future<void> addUser(String username, String gender, String email) async {
    final CollectionReference userCollection =
        FirebaseFirestore.instance.collection('User');
    try {
      await userCollection.doc(uid).set({
        'Username': username,
        'Gender': gender,
        'Email': email,
      });
    } catch (e) {
      print('Error adding data: $e');
    }
  }

  Future<void> checkPassIsExpirOrNot() async {
    DocumentSnapshot document = await FirebaseFirestore.instance
        .collection('User')
        .doc(uid)
        .collection('ActivePass')
        .doc('sam7770008123')
        .get();
    if (document.exists) {
      Map<String, dynamic>? data = document.data() as Map<String, dynamic>?;
      Timestamp timestamp = data!['Expiry_date'];
      DateTime expiryDate = timestamp.toDate();
      int expDay = expiryDate.day;
      int expMonth = expiryDate.month;

      DateTime now = DateTime.now();
      String formattedDateTime = "${now.toLocal()}".split('.')[0];
      DateFormat formatter = DateFormat("yyyy-MM-dd HH:mm:ss");
      DateTime currentDate = formatter.parse(formattedDateTime);
      int currentDay = currentDate.day;
      int currentMonth = currentDate.month;

      if (currentDay >= expDay && currentMonth >= expMonth) {
        await addActivePassDelete();
      }
    }
  }
}
