import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_application_2/service/user.dart';

class MyAuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  MyUser? _userFromFirebaseUser(User user) {
    return user != null ? MyUser(uid: user.uid) : null;
  }

  Stream<MyUser?> get user {
    return _auth
        .authStateChanges()
        .map((User? user) => _userFromFirebaseUser(user!));
  }

  Future signInWithEmail(String email, String password) async {
    try {
      UserCredential result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);

      User? user = result.user;
      return user;
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  // Register user with eamil and password
  Future registerWithEamil(String email, String password) async {
    try {
      UserCredential result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      User? user = result.user;
      return _userFromFirebaseUser(user!);
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  Future signout() async {
    try {
      print("hiiiiiiiiiiiiiiiiiiiiiiiii");
      return await _auth.signOut();
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  String getCurrentUid() {
    final User? user = _auth.currentUser;
    return user != null ? user.uid : '';
  }
}
