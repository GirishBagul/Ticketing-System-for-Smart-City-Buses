// ignore_for_file: prefer_interpolation_to_compose_strings
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter_application_2/widgets/history.dart';
import 'package:flutter_application_2/service/auth.dart';

class MyDrawer extends StatelessWidget {
  MyDrawer({super.key});
  final MyAuthService _auth = MyAuthService();
  @override
  Widget build(BuildContext context) {
    String uid = _auth.getCurrentUid();
    return Drawer(
      child: ListView(
        children: [
          StreamBuilder(
            stream: FirebaseFirestore.instance
                .collection('User')
                .doc(uid)
                .snapshots(),
            builder: (context, snapshot) {
              if (snapshot.connectionState == ConnectionState.waiting) {
                return const Center(
                  child: CircularProgressIndicator(),
                ); // Display a loading indicator while waiting for data.
              }
              if (!snapshot.hasData || snapshot.data == null) {
                return const Text('No data available');
              }
              if (snapshot.hasError) {
                return Text('Error: ${snapshot.error}');
              }
              var userData = snapshot.data;
              return UserAccountsDrawerHeader(
                accountName: Text('Welcome  ' + userData!['Username']),
                accountEmail: Text(userData['Email']),
                currentAccountPicture: const CircleAvatar(),
              );
            },
          ),
          ListTile(
            leading: const Icon(Icons.home),
            title: const Text('Home'),
            onTap: () {
              Navigator.pop(context); // Close the drawer
            },
          ),
          ListTile(
            leading: const Icon(Icons.person),
            title: const Text('Personal Details'),
            onTap: () {
              Navigator.pop(context); // Close the drawer
            },
          ),
          ListTile(
            leading: const Icon(Icons.history),
            title: const Text('BusPass History'),
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (context) => History(uid: uid))); // Close the drawer
            },
          ),
          ListTile(
            leading: const Icon(Icons.group),
            title: const Text('About Us'),
            onTap: () {
              Navigator.pop(context); // Close the drawer
            },
          ),
          ListTile(
            leading: const Icon(Icons.logout),
            title: const Text('LogOut'),
            onTap: () async {
              // Close the drawer
              await _auth.signout();
            },
          ),
        ],
      ),
    );
  }
}
