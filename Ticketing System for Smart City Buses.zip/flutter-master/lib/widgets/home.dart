import 'package:flutter/material.dart';

import 'package:flutter_application_2/service/auth.dart';
import 'package:flutter_application_2/widgets/mydrawer.dart';
import 'package:flutter_application_2/widgets/active_pass.dart';
import 'package:flutter_application_2/widgets/history.dart';
import 'package:flutter_application_2/service/database.dart';
import 'package:flutter_application_2/widgets/tickitpage.dart';
import 'package:flutter_application_2/service/custom_navigator.dart';

void main() {
  runApp(const Home());
}

class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _homeState();
}

// ignore: camel_case_types
class _homeState extends State<Home> {
  final MyAuthService _auth = MyAuthService();

  void _openActivePassModal() {
    showModalBottomSheet(context: context, builder: (ctx) => const Pass());
  }

  @override
  Widget build(BuildContext context) {
    final String uid = _auth.getCurrentUid();
    final DatabaseService database = DatabaseService(uid: uid);

    return Scaffold(
      appBar: AppBar(
        title: const Text("MetaBus"),
      ),
      drawer: MyDrawer(),
      body: Scaffold(
        body: SingleChildScrollView(
          child: Center(
            child: Column(
              children: [
                const SizedBox(height: 27),
                const Icon(Icons.qr_code, size: 100),
                SizedBox(
                  height: 40,
                  width: 250,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.of(context).push(MaterialPageRoute(
                        builder: (ctx) => const HomeScreen(),
                      ));
                    },
                    child: const Text(
                      "QR Scanner",
                      style: TextStyle(fontSize: 24),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 10,
                ),
                const Icon(Icons.card_membership, size: 100),
                SizedBox(
                  height: 40,
                  width: 250,
                  child: ElevatedButton(
                    onPressed: () {
                      CustomNavigator().navigateToBuspass(context);
                    },
                    child: const Text(
                      "Bus Pass",
                      style: TextStyle(fontSize: 24),
                    ),
                  ),
                ),
                const SizedBox(
                  height: 40,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 17,
                    ),
                    SizedBox(
                      height: 40,
                      width: 150,
                      child: ElevatedButton(
                        onPressed: () async {
                          await database.addActivePassDelete();
                        },
                        child: const Text(
                          "Personal details",
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 30,
                    ),
                    SizedBox(
                      height: 40,
                      width: 150,
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (ctx) => History(uid: uid)));
                        },
                        child: const Text(
                          "Travel history",
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(
                  height: 29,
                ),
                Row(
                  children: [
                    const SizedBox(
                      width: 17,
                    ),
                    SizedBox(
                      height: 40,
                      width: 150,
                      child: ElevatedButton(
                        onPressed: () {
                          database.checkPassIsExpirOrNot();
                          _openActivePassModal();
                        },
                        child: const Text(
                          "Active Pass",
                          style: TextStyle(fontSize: 15),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 30,
                    ),
                  ],
                ),
                const SizedBox(
                  height: 20.0,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
