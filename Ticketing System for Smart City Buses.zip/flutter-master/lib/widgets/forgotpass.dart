import 'package:flutter/material.dart';
import 'package:flutter_application_2/utils/routes.dart';

void main() {
  runApp(const ForgotPasswprd());
}

class ForgotPasswprd extends StatefulWidget {
  const ForgotPasswprd({super.key});

  @override
  State<ForgotPasswprd> createState() => _ForgotPasswprdState();
}

class _ForgotPasswprdState extends State<ForgotPasswprd> {
  bool _obscureText2 = true;
  bool _obscureText1 = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Forgot password"),
      ),
      body: Column(
        children: [
          Expanded(
              flex: 2,
              child: Container(
                child: Padding(
                  padding: const EdgeInsets.all(25.0),
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        const SizedBox(
                          height: 18,
                        ),
                        const Text(
                          "Forgot Password ?",
                          style: TextStyle(fontSize: 25),
                        ),
                        const SizedBox(height: 40),
                        TextField(
                          decoration: InputDecoration(
                              prefixIcon: const Icon(Icons.lock),
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _obscureText1 = !_obscureText1;
                                  });
                                },
                                child: Icon(_obscureText1
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                              ),
                              border: const OutlineInputBorder(),
                              labelText: "New password"),
                          obscureText: _obscureText1,
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          decoration: InputDecoration(
                              prefixIcon: const Icon(Icons.password_rounded),
                              suffixIcon: GestureDetector(
                                onTap: () {
                                  setState(() {
                                    _obscureText2 = !_obscureText2;
                                  });
                                },
                                child: Icon(_obscureText2
                                    ? Icons.visibility
                                    : Icons.visibility_off),
                              ),
                              border: const OutlineInputBorder(),
                              labelText: "Confirm password"),
                          obscureText: _obscureText2,
                        ),
                        const SizedBox(
                          height: 40,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.pushNamed(context, MyRoutes.loginroute);
                          },
                          child: AnimatedContainer(
                            duration: const Duration(seconds: 1),
                            height: 40,
                            width: 180,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(50),
                              color: Colors.blue,
                            ),
                            child: const Text(
                              "Confirm",
                              style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 20,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        Image.asset("assets/images/ForgotPasswprd.jpg"),
                      ],
                    ),
                  ),
                ),
                // color: Colors.green,
              )),
          // Expanded(
          //     child: Container(
          //   color: Colors.blue,
          // ))
        ],
      ),
    );
  }
}
