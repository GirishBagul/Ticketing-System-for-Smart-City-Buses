import 'package:intl/intl.dart';
import 'package:flutter/material.dart';

import 'package:flutter_application_2/widgets/active_pass.dart';
import 'package:flutter_application_2/service/auth.dart';
import 'package:flutter_application_2/service/database.dart';

void main() {
  runApp(const BusPass());
}

class BusPass extends StatefulWidget {
  const BusPass({super.key});

  @override
  State<BusPass> createState() => _BusPassState();
}

class _BusPassState extends State<BusPass> {
  // final Recipt recipt = Recipt();

  final DatabaseService d = DatabaseService(uid: 'uid');
  String nameCity = "";
  final _duration = ['Select', '24 Hours', '1 week', '1 month'];
  var _currentItemSelected = 'Select';

  String name = '';
  String phone = '';
  int baseprice = 50;
  late int totalprice;
  late DateTime expDate;

  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final MyAuthService _auth = MyAuthService();
  final _formkey = GlobalKey<FormState>();

  @override
  void dispose() {
    // Clean up the controllers when the widget is disposed.
    nameController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final String uid = _auth.getCurrentUid();
    final DatabaseService database = DatabaseService(uid: uid);

    void validEnterdDate() async {
      if (nameController.text.trim().isEmpty ||
          phoneController.text.trim().isEmpty ||
          phoneController.text.length < 10) {
        showDialog(
          context: context,
          builder: (context) => AlertDialog(
            title: const Text('Invalid input'),
            content: const Text(
                'Make sure you entered name, phone and pass duration. '),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('Okay'),
              )
            ],
          ),
        );
        return;
      }
      DateTime now = DateTime.now();

      // Format the date and time as a string
      String formattedDateTime = "${now.toLocal()}".split('.')[0];
      DateFormat formatter = DateFormat("yyyy-MM-dd HH:mm:ss");
      DateTime currentDate = formatter.parse(formattedDateTime);

      if (_currentItemSelected == '24 Hours') {
        totalprice = baseprice * 1;
        expDate = currentDate.add(const Duration(days: 1));
      } else if (_currentItemSelected == '1 week') {
        totalprice = baseprice * 7;
        expDate = currentDate.add(const Duration(days: 7));
      } else if (_currentItemSelected == '1 month') {
        totalprice = baseprice * 30;
        expDate = currentDate.add(const Duration(days: 30));
      }
      print(expDate);

      database.addPassHistory(
          name, phone, _currentItemSelected, formattedDateTime, expDate);
      database.addActivePass(
          name, phone, _currentItemSelected, formattedDateTime, expDate);

      // Clear the TextFormFields
      nameController.clear();
      phoneController.clear();

      Navigator.of(context)
          .push(MaterialPageRoute(builder: (context) => const Pass()));
    }

    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Bus Pass"),
        leading: BackButton(onPressed: () {
          Navigator.pop(context);
        }),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Form(
              key: _formkey,
              child: Column(
                children: [
                  const SizedBox(
                    height: 40,
                  ),
                  // const Text(
                  //   "!!Welcome To MetaBus Pass!!",
                  //   style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold),
                  // ),
                  const SizedBox(
                    height: 35,
                  ),
                  const Text(
                    "Select pass duration",
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  DropdownButton<String>(
                    items: _duration.map((String dropDownStringItem) {
                      return DropdownMenuItem<String>(
                        value: dropDownStringItem,
                        child: Text(dropDownStringItem),
                      );
                    }).toList(),
                    onChanged: (newValueSelected) {
                      setState(() {
                        _currentItemSelected = newValueSelected!;
                      });
                    },
                    value: _currentItemSelected,
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  TextFormField(
                    controller: nameController,
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: "Name",
                        labelStyle: TextStyle(fontSize: 17)),
                    onChanged: (value) {
                      setState(() {
                        name = value;
                      });
                    },
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  TextFormField(
                    controller: phoneController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                        border: OutlineInputBorder(),
                        labelText: "Phone No.",
                        labelStyle: TextStyle(fontSize: 17)),
                    onChanged: (value) {
                      setState(() {
                        phone = value;
                      });
                    },
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  InkWell(
                    onTap: validEnterdDate,
                    child: AnimatedContainer(
                      duration: const Duration(seconds: 1),
                      height: 40,
                      width: 180,
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.blue,
                      ),
                      child: const Text(
                        "Confirm",
                        style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
