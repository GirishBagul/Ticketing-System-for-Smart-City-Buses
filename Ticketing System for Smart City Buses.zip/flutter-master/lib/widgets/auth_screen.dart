import 'package:flutter/material.dart';
import 'package:flutter_application_2/widgets/login.dart';
import 'package:flutter_application_2/widgets/signup.dart';

// ignore: camel_case_types
class authenticate extends StatefulWidget {
  const authenticate({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _AuthenticateState createState() => _AuthenticateState();
}

class _AuthenticateState extends State<authenticate> {
  bool showSignIn = true;

  void toggle() {
    setState(() {
      showSignIn = !showSignIn;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (showSignIn) {
      return SignInScreen(toggle);
    } else {
      return Register(toggle);
    }
  }
}
