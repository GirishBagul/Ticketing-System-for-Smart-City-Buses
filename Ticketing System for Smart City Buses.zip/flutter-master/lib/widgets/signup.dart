import 'package:flutter/material.dart';
import 'package:flutter_application_2/service/auth.dart';
import 'package:flutter_application_2/service/database.dart';

class Register extends StatefulWidget {
  const Register(this.toggle, {super.key});
  final Function toggle;
  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  String email = '';
  String password = '';
  String username = '';
  String gender = '';
  String error = '';
  bool pass = false;

  final MyAuthService _auth = MyAuthService();

  final _formkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        elevation: 0.0,
        title: const Text('Sign Up'),
        actions: <Widget>[
          TextButton.icon(
            onPressed: () {
              widget.toggle();
            },
            icon: const Icon(Icons.person, color: Colors.white),
            label: const Text(
              "Sing In",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: Container(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 50.0),
        child: Form(
          key: _formkey,
          child: SingleChildScrollView(
            child: Column(
              children: <Widget>[
                const SizedBox(height: 20.0),
                TextFormField(
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Enter Username";
                    } else {
                      return null;
                    }
                  },
                  decoration: const InputDecoration(
                    // hintText: "Username",
                    label: Text('Username'),
                  ),
                  onChanged: (val) {
                    setState(() {
                      username = val;
                    });
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Enter Gender eg. Male or Female";
                    } else {
                      return null;
                    }
                  },
                  decoration: const InputDecoration(
                    // hintText: "Gender",
                    label: Text('Gender'),
                  ),
                  onChanged: (val) {
                    setState(() {
                      gender = val;
                    });
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  keyboardType: TextInputType.emailAddress,
                  validator: (val) {
                    if (val!.isEmpty) {
                      return "Enter valid eamil!";
                    } else {
                      return null;
                    }
                  },
                  decoration: const InputDecoration(
                    // hintText: "Email",
                    label: Text('Email'),
                  ),
                  onChanged: (val) {
                    setState(() {
                      email = val;
                    });
                  },
                ),
                const SizedBox(height: 20.0),
                TextFormField(
                  validator: (val) {
                    if (val!.length < 6) {
                      return "Password lenght should be more than 6 characters";
                    } else {
                      return null;
                    }
                  },
                  decoration: InputDecoration(
                    // hintText: "Password",
                    label: const Text('Password'),
                    suffixIcon: IconButton(
                        onPressed: () {
                          setState(() {
                            pass = !pass;
                          });
                        },
                        icon: pass
                            ? const Icon(Icons.visibility_off_outlined)
                            : const Icon(Icons.visibility_outlined)),
                  ),
                  obscureText: pass ? false : true,
                  onChanged: (val) {
                    setState(() {
                      password = val;
                    });
                  },
                ),
                const SizedBox(
                  height: 40.0,
                ),
                ElevatedButton(
                  onPressed: () async {
                    if (_formkey.currentState!.validate()) {
                      dynamic result =
                          await _auth.registerWithEamil(email, password);
                      final String uid = _auth.getCurrentUid();
                      final DatabaseService _database =
                          DatabaseService(uid: uid);
                      _database.addUser(username, gender, email);

                      if (result == null) {
                        setState(() {
                          error = "Error try again!!";
                        });
                      }
                    }
                  },
                  child: const Text(
                    "Register",
                    style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                  ),
                ),
                const SizedBox(
                  height: 20.0,
                ),
                Text(
                  error,
                  style: const TextStyle(color: Colors.red, fontSize: 17.0),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
