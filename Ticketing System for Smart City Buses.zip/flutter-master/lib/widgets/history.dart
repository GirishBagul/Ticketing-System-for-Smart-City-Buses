import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class History extends StatelessWidget {
  History({super.key, required this.uid});
  String uid;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Travel history"),
        leading: BackButton(
          onPressed: () {
            Navigator.of(context).pop();
          },
        ),
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('User')
            .doc(uid)
            .collection('PassHistory')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          }
          if (snapshot.hasError) {
            return Text("Error: ${snapshot.error}");
          }
          if (snapshot.data != null) {
            final historyList = snapshot.data!.docs;
            // ignore: avoid_print
            print("Received ${historyList.length} history items");
            if (historyList.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/img/no_history.png",
                    ),
                    const Text(
                      "No History!",
                      style: TextStyle(fontSize: 20),
                    ),
                  ],
                ),
              );
            }
            return ListView.builder(
              itemCount: historyList.length,
              itemBuilder: (context, index) {
                final data = historyList[index].data() as Map<String, dynamic>;
                return SingleChildScrollView(
                  child: Column(
                    children: [
                      const SizedBox(
                        height: 10,
                      ),
                      Container(
                        padding: const EdgeInsets.all(12),
                        height: 100,
                        width: 340,
                        decoration: const BoxDecoration(
                          color: Colors.white,
                          boxShadow: [
                            BoxShadow(
                              color: Colors.grey, // Shadow color
                              offset: Offset(0, 2), // Offset from the container
                              blurRadius: 5, // Spread radius
                            ),
                          ],
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment
                              .start, // Align text to the left
                          children: [
                            Text('Name : ${data['name']}'),
                            Text('Phone No. : ${data['phone']}'),
                            Text('purchased Date : ${data['purchased_date']}'),
                            Text('Duration : ${data['duration']}'),
                          ],
                        ),
                      ),
                    ],
                  ),
                );
              },
            );
          } else {
            return const Text("No data available");
          }
        },
      ),
    );
  }
}
