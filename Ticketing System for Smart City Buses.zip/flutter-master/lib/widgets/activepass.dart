import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_application_2/service/auth.dart';

class ActivePass extends StatefulWidget {
  const ActivePass({super.key});

  @override
  State<ActivePass> createState() => _ActivePassState();
}

class _ActivePassState extends State<ActivePass> {
  final MyAuthService _auth = MyAuthService();
  @override
  Widget build(BuildContext context) {
    String uid = _auth.getCurrentUid();
    return StreamBuilder(
        stream: FirebaseFirestore.instance
            .collection('User')
            .doc(uid)
            .collection('ActivePass')
            .snapshots(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const CircularProgressIndicator(); // Display a loading indicator while waiting for data.
          }
          if (!snapshot.hasData || snapshot.data == null) {
            return const Text('No data available');
          }
          if (snapshot.hasError) {
            return Text('Error: ${snapshot.error}');
          }
          return const Scaffold(
            body: Column(
              children: [Text('has')],
            ),
          );
        });
  }
}
