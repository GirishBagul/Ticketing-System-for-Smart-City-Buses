import 'package:flutter/material.dart';
import 'package:flutter_application_2/service/auth.dart';

// ignore: camel_case_types
class SignInScreen extends StatefulWidget {
  const SignInScreen(this.toggle, {super.key});
  final Function toggle;
  @override
  // ignore: library_private_types_in_public_api
  _SignInScreenState createState() => _SignInScreenState();
}

class _SignInScreenState extends State<SignInScreen> {
  String email = '';
  String password = '';
  String error = '';
  bool pass = false;

  final MyAuthService _auth = MyAuthService();
  final _formkey = GlobalKey<FormState>();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue[100],
      appBar: AppBar(
        backgroundColor: Colors.blue[400],
        elevation: 0.0,
        title: const Text('Sign In'),
        actions: <Widget>[
          TextButton.icon(
            onPressed: () {
              widget.toggle();
            },
            icon: const Icon(Icons.person, color: Colors.white),
            label: const Text(
              "Register",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: Container(
        padding: const EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
        child: Form(
          key: _formkey,
          child: Column(
            children: <Widget>[
              const SizedBox(height: 20.0),
              TextFormField(
                keyboardType: TextInputType.emailAddress,
                validator: (value) {
                  if (value!.isEmpty) {
                    return "Enter valid email!";
                  } else {
                    return null;
                  }
                },
                decoration: const InputDecoration(
                  // hintText: "Email",
                  label: Text('Email'),
                  // border: OutlineInputBorder(
                  //   borderRadius: BorderRadius.all(
                  //     Radius.circular(10),
                  //   ),
                  // ),
                ),
                onChanged: (val) {
                  setState(() {
                    email = val;
                  });
                },
              ),
              const SizedBox(height: 20.0),
              TextFormField(
                validator: (value) {
                  if (value!.length < 6) {
                    return "At least 6 char for password!";
                  } else {
                    return null;
                  }
                },
                decoration: InputDecoration(
                  // border: const OutlineInputBorder(
                  //   borderRadius: BorderRadius.all(
                  //     Radius.circular(10),
                  //   ),
                  // ),
                  // hintText: "Password",
                  label: const Text('Password'),
                  suffixIcon: IconButton(
                      onPressed: () {
                        setState(() {
                          pass = !pass;
                        });
                      },
                      icon: pass
                          ? const Icon(Icons.visibility_off_outlined)
                          : const Icon(Icons.visibility_outlined)),
                ),
                obscureText: pass ? false : true,
                onChanged: (val) {
                  setState(() {
                    password = val;
                  });
                },
              ),
              const SizedBox(
                height: 40.0,
              ),
              ElevatedButton(
                onPressed: () async {
                  if (_formkey.currentState!.validate()) {
                    dynamic result =
                        await _auth.signInWithEmail(email, password);
                    if (result == null) {
                      setState(() => error =
                          'Could not sign in with those credentials !!');
                    }
                  }
                },
                child: const Text(
                  "Sign In",
                  style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
                ),
              ),
              const SizedBox(
                height: 20.0,
              ),
              Text(
                error,
                style: const TextStyle(color: Colors.red, fontSize: 17.0),
              )
            ],
          ),
        ),
      ),
    );
  }
}
