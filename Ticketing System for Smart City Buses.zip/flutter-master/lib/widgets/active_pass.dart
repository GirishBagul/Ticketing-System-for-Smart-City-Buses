import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import 'package:flutter_application_2/widgets/home.dart';
import 'package:flutter_application_2/service/auth.dart';
import 'package:intl/intl.dart';

class Pass extends StatefulWidget {
  const Pass({Key? key}) : super(key: key);

  @override
  State<Pass> createState() => _PassState();
}

class _PassState extends State<Pass> {
  final MyAuthService _auth = MyAuthService();

  @override
  Widget build(BuildContext context) {
    final uid = _auth.getCurrentUid();
    return Scaffold(
      appBar: AppBar(
        title: const Text("Bus Pass"),
        leading: BackButton(
          onPressed: () {
            Navigator.pushAndRemoveUntil(
              context,
              MaterialPageRoute(builder: (ctx) => const Home()),
              (route) => false,
            );
          },
        ),
      ),
      body: Center(
        child: StreamBuilder(
          stream: FirebaseFirestore.instance
              .collection('User')
              .doc(uid)
              .collection('ActivePass')
              .snapshots(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }

            if (!snapshot.hasData || snapshot.data == null) {
              return const Center(
                child: Text('No active pass available'),
              );
            }

            if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            }

            var documents = snapshot.data!.docs;

            if (documents.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      "assets/img/no_active_pass.png",
                    ),
                    const Text(
                      "No active pass available",
                      style: TextStyle(fontSize: 20),
                    ),
                  ],
                ),
              );
            }

            var data = documents.first.data();

            return Center(
              child: Container(
                padding: const EdgeInsets.all(23),
                height: 180,
                width: 350,
                decoration: const BoxDecoration(
                  borderRadius: BorderRadius.all(Radius.circular(15)),
                  color: Colors.white,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey, // Shadow color
                      offset: Offset(0, 2), // Offset from the container
                      blurRadius: 5, // Spread radius
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Name : ${data['name']}',
                      style: myTextStyle,
                    ),
                    Text(
                      'Phone No. : ${data['phone']}',
                      style: myTextStyle,
                    ),
                    Text(
                      'Purchased Date : ${data['purchased_date']}',
                      style: myTextStyle,
                    ),
                    Text(
                      'Duration : ${data['duration']}',
                      style: myTextStyle,
                    ),
                    // Text(
                    //   'Expiry : ${data['Expiry_date']}',
                    //   style: myTextStyle,
                    // ),
                  ],
                ),
              ),
            );
          },
        ),
      ),
    );
  }
}

TextStyle myTextStyle = const TextStyle(
  color: Colors.black, // Set your desired text color
  fontSize: 21, // Set your desired font size
);
