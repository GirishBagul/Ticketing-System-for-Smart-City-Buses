import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

// class TickitPage extends StatefulWidget {
//   const TickitPage({Key? key}) : super(key: key);

//   @override
//   _TickitPageState createState() => _TickitPageState();
// }

// class _TickitPageState extends State<TickitPage> {
//   String? _startPoint;
//   String? _endPoint;
//   int? _distance;
//   double? _cost;
// final Map<String, int> _distanceMap = {
//   'Swargate-Bhapkar Petrol Pump': 2500,
//   'Swargate-Bibwewadi': 2100,
//   'Swargate-Upper Depot': 6000,
//   'Bhapkar Petrol Pump-Bibwewadi': 600,
//   'Bhapkar Petrol Pump-Upper Depot': 3200,
//   'Bibwewadi-Upper Depot': 2900,
// };

//   final GlobalKey qrKey1 = GlobalKey(debugLabel: 'QR');
//   final GlobalKey qrKey2 = GlobalKey(debugLabel: 'QR');
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Ticket Booking"),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(16.0),
//         child: Column(
//           crossAxisAlignment: CrossAxisAlignment.start,
//           children: [
//             const Text("Start Point"),
//             SizedBox(
//               height: 200,
//               child: QRView(
//                 key: qrKey1,
//                 onQRViewCreated: (QRViewController controller) {
//                   controller.scannedDataStream.listen((scanData) {
//                     setState(() {
//                       _startPoint = scanData.code;
//                       _distance = _calculateDistance();
//                       _cost = _calculateCost();
//                     });
//                     controller.pauseCamera();
//                   });
//                 },
//               ),
//             ),
//             const SizedBox(height: 20),
//             const Text("End Point"),
//             SizedBox(
//               height: 200,
//               child: QRView(
//                 key: qrKey2,
//                 onQRViewCreated: (QRViewController controller) {
//                   controller.scannedDataStream.listen((scanData) {
//                     setState(() {
//                       _endPoint = scanData.code;
//                       _distance = _calculateDistance();
//                       _cost = _calculateCost();
//                     });
//                     controller.pauseCamera();
//                   });
//                 },
//               ),
//             ),
//             const SizedBox(height: 20),
//             _distance != null
//                 ? Text("Distance: $_distance miles")
//                 : const SizedBox(),
//             const SizedBox(height: 20),
//             _cost != null ? Text("Cost: $_cost") : const SizedBox(),
//             const SizedBox(height: 20),
//             ElevatedButton(
//               onPressed: _cost != null ? () => _pay() : null,
//               child: const Text("Pay"),
//             ),
//           ],
//         ),
//       ),
//     );
//   }

//   int? _calculateDistance() {
//     if (_startPoint != null && _endPoint != null) {
//       final key = '$_startPoint-$_endPoint';
//       if (_distanceMap.containsKey(key)) {
//         return _distanceMap[key];
//       }
//     }
//     return null;
//   }

//   double? _calculateCost() {
//     if (_distance != null) {
//       return _distance! * 0.5;
//     }
//     return null;
//   }

//   void _pay() {
//     // Simulating a payment process with a delay
//     showDialog(
//       context: context,
//       builder: (BuildContext context) {
//         return const AlertDialog(
//           title: Text('Processing Payment...'),
//           content: Text('Please wait while your payment is being processed.'),
//         );
//       },
//     );

//     Future.delayed(const Duration(seconds: 2), () {
//       // Payment successful
//       Navigator.pop(context); // Close the payment processing dialog

//       showDialog(
//         context: context,
//         builder: (BuildContext context) {
//           return AlertDialog(
//             title: const Text('Payment Successful'),
//             content:
//                 const Text('Your payment was successful. Enjoy your trip!'),
//             actions: [
//               TextButton(
//                 onPressed: () {
//                   Navigator.pop(context); // Close the success dialog
//                   // Reset the ticket information
//                   setState(() {
//                     _startPoint = null;
//                     _endPoint = null;
//                     _distance = null;
//                     _cost = null;
//                   });
//                 },
//                 child: const Text('OK'),
//               ),
//             ],
//           );
//         },
//       );
//     });
//   }
// }
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  // ignore: library_private_types_in_public_api
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final GlobalKey qrKey1 = GlobalKey(debugLabel: 'QR 1');
  final GlobalKey qrKey2 = GlobalKey(debugLabel: 'QR 2');
  late QRViewController controller1;
  late QRViewController controller2;
  String? qrCodeData1;
  String? qrCodeData2;
  late List<String> data1;
  late List<String> data2;
  late String _endPoint;
  late String _startPoint;

  int? _distance;
  double? _cost;
  final Map<String, int> _distanceMap = {
    'A-B': 2500,
    'A-A': 2100,
    'Swargate-Upper Depot': 6000,
    'Bhapkar Petrol Pump-Bibwewadi': 600,
    'Bhapkar Petrol Pump-Upper Depot': 3200,
    'Bibwewadi-Upper Depot': 2900,
  };

  void onQRViewCreated1(QRViewController controller) {
    controller1 = controller;
    controller.scannedDataStream.listen((scannedData) {
      setState(() {
        qrCodeData1 = scannedData.code;
        print("1 $qrCodeData1");
        data1 = qrCodeData1!.split(' ');
      });
      controller1.pauseCamera();
      if (qrCodeData1 != null && qrCodeData2 != null) {
        // Both QR codes scanned, check if they match
        if (data1[0] == data2[0]) {
          // Proceed when QR codes match
          print("QR codes match!");
        } else {
          _distance = _calculateDistance();
          _cost = _calculateCost();
          print(_cost);
          // Handle the case when QR codes do not match
          // print("QR codes do not match!");
          // ScaffoldMessenger.of(context).showSnackBar(
          //   const SnackBar(
          //     content: Text("Error: QR codes do not match!"),
          //   ),
          // );
        }
      }
    });
  }

  int? _calculateDistance() {
    _startPoint = data2[0];
    _endPoint = data1[0];
    if (_startPoint != null && _endPoint != null) {
      final key = '$_startPoint-$_endPoint';
      if (_distanceMap.containsKey(key)) {
        return _distanceMap[key];
      }
    }
    return null;
  }

  double? _calculateCost() {
    if (_distance != null) {
      return _distance! * 0.5;
    }
    return null;
  }

  void onQRViewCreated2(QRViewController controller) {
    controller2 = controller;
    controller.scannedDataStream.listen((scannedData) {
      setState(() {
        qrCodeData2 = scannedData.code;
        print("2 $qrCodeData2");
        data2 = qrCodeData2!.split(' ');
      });
      controller2.pauseCamera();
    });
  }

  void _pay() {
    // Simulating a payment process with a delay
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return const AlertDialog(
          title: Text('Processing Payment...'),
          content: Text('Please wait while your payment is being processed.'),
        );
      },
    );

    Future.delayed(const Duration(seconds: 2), () {
      // Payment successful
      Navigator.pop(context); // Close the payment processing dialog

      showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: const Text('Payment Successful'),
            content:
                const Text('Your payment was successful. Enjoy your trip!'),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context); // Close the success dialog
                  // Reset the ticket information
                  setState(() {
                    _startPoint = '';
                    _endPoint = '';
                    _distance = null;
                    _cost = null;
                  });
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('QR Code Scanner'),
      ),
      body: Center(
        child: Column(
          children: <Widget>[
            const SizedBox(
              height: 20,
            ),
            SizedBox(
              height: 200,
              width: 300,
              child: QRView(
                key: qrKey1,
                onQRViewCreated: onQRViewCreated1,
              ),
            ),
            const Text("Second QR code"),
            const SizedBox(
              height: 40,
            ),
            SizedBox(
              height: 200,
              width: 300,
              child: QRView(
                key: qrKey2,
                onQRViewCreated: onQRViewCreated2,
              ),
            ),
            const Text("First QR code"),
            const SizedBox(
              height: 20,
            ),
            ElevatedButton(
              onPressed: _cost != null ? () => _pay() : null,
              child: const Text("Pay"),
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    controller1.dispose();
    controller2.dispose();
    super.dispose();
  }
}
