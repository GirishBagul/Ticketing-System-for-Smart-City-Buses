import 'package:flutter/material.dart';
import 'package:flutter_application_2/utils/routes.dart';

void main() {
  runApp(const PersonalDetails());
}

class PersonalDetails extends StatelessWidget {
  const PersonalDetails({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: const Text("Personal Details"),
        leading: BackButton(
          onPressed: () {
            Navigator.pushNamed(context, MyRoutes.homeroute);
          },
        ),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Center(
            child: Column(
              children: [
                const SizedBox(
                  height: 50,
                ),
                Image.asset(
                  "assets/images/bus.jpg",
                  fit: BoxFit.fitWidth,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
